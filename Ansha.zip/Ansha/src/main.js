import { renderSidebar, bindSidebarEvents } from './components/Sidebar.js';
import { renderHome, bindHomeEvents } from './pages/Home.js';
import { renderClasses } from './pages/Classes.js';
import { renderClassDetail, bindClassDetailEvents } from './pages/ClassDetail.js';
import { renderAssignments, bindAssignmentsEvents } from './pages/Assignments.js';
import { renderCalendar, bindCalendarEvents } from './pages/Calendar.js';
import { renderIBCore } from './pages/IBCore.js';
import { renderSchool, bindSchoolEvents } from './pages/School.js';
import { renderProfile } from './pages/Profile.js';
import { renderLogin, bindLoginEvents } from './pages/Login.js';
import { renderAdmin } from './pages/Admin.js';
import { getSession, hydrateSession, logout } from './data/auth.js';

const appContent = document.getElementById('app-content');
const sidebarRoot = document.getElementById('sidebar-root');

let assignmentsFilter = 'All';

function parseHash() {
  const hash = window.location.hash.replace(/^#\/?/, '');
  const parts = hash.split('/').filter(Boolean);
  return parts.length ? parts : ['home'];
}

function navigate(route) { window.location.hash = `#/${route}`; }

function renderRoute() {
  const session = hydrateSession();

  if (!session) {
    sidebarRoot.innerHTML = '';
    appContent.innerHTML = renderLogin();
    bindLoginEvents(() => {
      window.location.hash = '#/home';
    });
    return;
  }

  const [section, ...rest] = parseHash();
  document.getElementById('modal-root').innerHTML = '';

  if (session.role === 'admin') {
    sidebarRoot.innerHTML = renderAdminSidebar();
    bindAdminSidebarEvents();
  } else {
    sidebarRoot.innerHTML = renderSidebar(section);
    bindSidebarEvents(navigate);
  }

  if (session.role === 'admin') {
    if (section === 'logout') {
      logout();
      window.location.hash = '#/login';
      return;
    }
    appContent.innerHTML = renderAdmin();
    window.scrollTo({top:0, behavior:'auto'});
    return;
  }

  switch(section) {
    case 'home':
      appContent.innerHTML = renderHome();
      bindHomeEvents();
      break;
    case 'classes':
      if (rest[0]) {
        const tab = rest[1] ? decodeURIComponent(rest[1]) : 'Overview';
        appContent.innerHTML = renderClassDetail(rest[0], tab);
        bindClassDetailEvents(rest[0], (id, newTab) => {
          window.location.hash = `#/classes/${id}/${encodeURIComponent(newTab)}`;
        });
      } else appContent.innerHTML = renderClasses();
      break;
    case 'assignments':
      appContent.innerHTML = renderAssignments(assignmentsFilter);
      bindAssignmentsEvents(filter => { assignmentsFilter = filter; renderRoute(); });
      break;
    case 'calendar':
      appContent.innerHTML = renderCalendar(new Date().getFullYear(), new Date().getMonth());
      bindCalendarEvents();
      break;
    case 'ib-core':
      appContent.innerHTML = renderIBCore();
      break;
    case 'cas':
      appContent.innerHTML = renderIBCore('CAS');
      break;
    case 'ee':
      appContent.innerHTML = renderIBCore('EE');
      break;
    case 'school':
      appContent.innerHTML = renderSchool();
      bindSchoolEvents();
      break;
    case 'profile':
      appContent.innerHTML = renderProfile();
      break;
    case 'logout':
      logout();
      window.location.hash = '#/login';
      return;
    case 'login':
      window.location.hash = '#/home';
      return;
    default:
      window.location.hash = '#/home';
      return;
  }
  window.scrollTo({top:0, behavior:'auto'});
}

function renderAdminSidebar() {
  return `
    <nav class="sidebar" aria-label="Admin navigation">
      <div class="sidebar-brand">
        <div class="sidebar-brand-mark">A</div>
        <div>
          <div class="sidebar-brand-name">Ansha</div>
          <span class="sidebar-brand-school">Chaman Bharatiya School</span>
        </div>
      </div>
      <div class="sidebar-nav">
        <button class="sidebar-nav-item is-active" type="button"><span class="nav-icon">⌂</span><span>Admin home</span></button>
        <button class="sidebar-nav-item" type="button"><span class="nav-icon">◉</span><span>Students</span></button>
        <button class="sidebar-nav-item" type="button"><span class="nav-icon">◇</span><span>Staff</span></button>
        <button class="sidebar-nav-item" type="button"><span class="nav-icon">▦</span><span>Classes</span></button>
      </div>
      <div class="sidebar-footer">
        <button class="sidebar-user" data-admin-logout type="button">
          <div class="sidebar-user-avatar">A</div>
          <div>
            <div class="sidebar-user-name">Admin</div>
            <div class="sidebar-user-role">Administrator · Log out</div>
          </div>
        </button>
      </div>
    </nav>`;
}

function bindAdminSidebarEvents() {
  document.querySelector('[data-admin-logout]')?.addEventListener('click', () => {
    logout();
    window.location.hash = '#/login';
  });
}

window.addEventListener('hashchange', renderRoute);
window.addEventListener('DOMContentLoaded', () => {
  if (!window.location.hash) window.location.hash = '#/home';
  else renderRoute();
});
