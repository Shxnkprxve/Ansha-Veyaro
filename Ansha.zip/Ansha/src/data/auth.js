import { student, setActiveStudent, resetStudent } from './student.js';

const SESSION_KEY = 'ansha_session';

const ACCOUNTS = {
  Admin: {
    username: 'Admin',
    password: '1234',
    role: 'admin',
    displayName: 'Admin',
  },
  's28001@cbs.in': {
    username: 's28001@cbs.in',
    password: '12345678',
    role: 'student',
    displayName: 'Shankar',
    student: {
      preferredName: 'Shankar',
      fullName: 'Shankar',
      initials: 'S',
      yearGroup: 'DP1',
      programme: 'IB Diploma Programme',
      studentId: 'C28001',
      school: 'Chaman Bharatiya School',
    },
  },
  'S30001@cbs.in': {
    username: 'S30001@cbs.in',
    password: '201010',
    role: 'student',
    displayName: 'Anagha',
    student: {
      preferredName: 'Anagha',
      fullName: 'Anagha',
      initials: 'A',
      yearGroup: 'DP1',
      programme: 'IB Diploma Programme',
      studentId: 'C30001',
      school: 'Chaman Bharatiya School',
    },
  },
};

export function login(username, password) {
  const account = ACCOUNTS[username];
  if (!account || account.password !== password) return { ok: false };

  const session = {
    username: account.username,
    role: account.role,
    displayName: account.displayName,
    student: account.student || null,
  };

  sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
  if (account.student) setActiveStudent(account.student);

  return { ok: true, session };
}

export function getSession() {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    sessionStorage.removeItem(SESSION_KEY);
    return null;
  }
}

export function hydrateSession() {
  const session = getSession();
  if (session?.student) setActiveStudent(session.student);
  else resetStudent();
  return session;
}

export function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  resetStudent();
}

export function isLoggedIn() {
  return Boolean(getSession());
}

export function isAdmin() {
  return getSession()?.role === 'admin';
}

export { student };
