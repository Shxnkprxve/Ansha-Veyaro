import { student } from '../data/student.js';
export function renderProfile() {
  return `<div class="fade-in"><div class="profile-identity"><div class="profile-avatar">${student.initials}</div><div><div class="welcome-eyebrow">${student.yearGroup} Student</div><h1 class="page-title">${student.fullName}</h1><p class="page-subtitle">${student.programme}</p></div></div><div class="profile-columns"><section><div class="welcome-eyebrow">School</div><strong>${student.school}</strong></section><section><div class="welcome-eyebrow">Programme</div><strong>${student.programme}</strong></section><section><div class="welcome-eyebrow">Student ID</div><strong>${student.studentId || 'Not assigned'}</strong></section></div></div>`;
}
