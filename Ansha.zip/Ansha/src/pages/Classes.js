import { classes } from '../data/classes.js';
export function renderClasses() {
  return `<div class="fade-in">
    <div class="page-header"><h1 class="page-title">Classes</h1><p class="page-subtitle">Your DP1 subjects and learning spaces.</p></div>
    <div class="card" style="padding:8px 18px;">
      ${classes.map(c => `<a class="class-row" href="#/classes/${c.id}">
        <span class="class-row-dot"></span><div><h2>${c.name}</h2><p>${c.teacher} · ${c.room}</p></div>
        <span class="pill pill-accent">${c.colour}</span><b>→</b>
      </a>`).join('')}
    </div>
  </div>`;
}
