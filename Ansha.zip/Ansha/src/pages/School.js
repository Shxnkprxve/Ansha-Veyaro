import { announcements } from '../data/announcements.js';
import { openModal } from '../components/Modal.js';
export function renderSchool() {
  return `<div class="fade-in"><div class="page-header"><h1 class="page-title">School</h1><p class="page-subtitle">Announcements and school information.</p></div><div class="card announcement-list" style="padding:10px;">${announcements.map(a=>`<button class="announcement-item" data-school-announcement="${a.id}"><span class="announcement-dot"></span><span><div class="announcement-title">${a.title}</div><div class="announcement-desc">${a.summary}</div></span></button>`).join('')}</div></div>`;
}
export function bindSchoolEvents(){ document.querySelectorAll('[data-school-announcement]').forEach(el=>el.addEventListener('click',()=>{const a=announcements.find(x=>x.id===el.dataset.schoolAnnouncement); if(a) openModal({title:a.title,metaHtml:`<span class="pill pill-neutral">${a.date}</span>`,bodyHtml:`<p>${a.body}</p>`});})); }
