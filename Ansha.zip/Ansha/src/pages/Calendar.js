import { WEEKDAYS } from '../data/schedule.js';
export function renderCalendar(year, month) {
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month+1, 0).getDate();
  const cells = [];
  for(let i=0;i<(first===0?6:first-1);i++) cells.push('<div class="calendar-cell"></div>');
  for(let d=1;d<=days;d++) cells.push(`<div class="calendar-cell"><div class="calendar-day">${d}</div>${d===18?'<div class="calendar-event">Maths · Practice set</div>':''}${d===20?'<div class="calendar-event">English · Reading</div>':''}</div>`);
  return `<div class="fade-in"><div class="page-header"><h1 class="page-title">Calendar</h1><p class="page-subtitle">${new Date(year,month).toLocaleString('en-GB',{month:'long',year:'numeric'})}</p></div><div class="calendar-grid">${cells.join('')}</div></div>`;
}
export function bindCalendarEvents() {}
